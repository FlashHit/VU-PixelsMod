# Original version:
## VU-MajorsMod MajorVictory87
- Stunts mod for Battlefield 3: Venice Unleashed
- https://github.com/MajorVictory/VU-MajorsMod

# Modded version:
## iamadeadpixel
- Make things go more fun and kinky
-
- Read down below the changes
- Version 1.4.4 (17-07-2022)
-
# WARNING
* DO NOT RUN THIS MOD WITH MAJORVICTORY87 ! IT WILL GIVE MASSIVE CONFLICTS !

# About me:
- Short: i am a lazy prick, not the pro in coding but am pretty good in understand the programming concept.
- so, copy past and adapt is pretty swag for me..

# Known isues
* This mod can give conflicts with the funbots mod, and nags the server to reboot.
* USE WITH CARE !

# How to adjust settings on the __init_modules files
- __init__.lua : This is the master file
- Here u can enable or fully disable the modules
- true or false can be used, also hidden, this wil supress any text output on the server on startup

- __init_Generic_Modules.lua
- Here u can enable or disable player tweaks and some Weapon stuff, this is a WIP,so disabled.

- __init_Global_init_module.lua
- Here u can enable or disable sub modules,each module contains classes for its core.

- __init_modules_choppers.lua
- Here u can enable or disable any chopper type there is.

- __init_modules_common_weapons.lua
- Here u can enable or disable the common shared weapons.

- __init_modules_assault_weapons.lua
- Here u can enable or disable ALL modded assault weapons

- __init_modules_recon_weapons.lua
- Here u can enable or disable the recon class weapons

- __init_modules_support.lua
- Here u can enable or disable the default support class weapons

- __init_modules_support_LMG.lua
- Here u can enable or disable all the LMG classes

- __init_modules_engineer_weapons.lua
- Here u can enable or disable the engineer class weapons

- __init_modules_gadgets.lua
- Here u can enable or disable most of the gadgets.

- __init_modules_handguns.lua
- Here u can enable or disable most of the handguns (still WIP,but working)

- __init_modules_rockets.lua
- Here u can enable or disable RPG/IGLA/STINGER

- __init_modules_shotguns.lua
- Here u can enable or disable the shotguns

- __init_modules_vehicles.lua
- Here u can enable or disable most of the vehicles weapon mods


# Last update: 17-07-2022
# Changed C4,Grenades,Claymores,M15: Normal or turbo mode.
- Normal mode: Behaves as stock stuff.
- Turbo mode: Things goes BOOOOOOOOOOM !
- Added small variable section in C4,M15,claymore and grenade turbo mode
- for faster modifications. - Regular values on the end.

# previous update: 29-06-2022
Make more fun with the EOD bot
Now u can select in the config normale long distance repair, or super charched rockets with repair fun

# Previous update: 26-06-2022
Make more fun with grenades.
Now u can select in the config normale grenades, or super charched grenades

# Previous update: 06-05-2022
- MP443 Gun Master Modded ammo size
- Magnum 44 Gun Master Modded ammo size
- Changed Magnum 44 scoped entity
- M9 Gun Master Modded ammo size
- Changed BTR-90 - BMP-2M - LAV-25 Ammo size, from 9 to 24
- Changed Phoenix - Barsuk Ammo size, from 9 to 24
- Changed Amtrav AAV-7a1 Ammo size, from 9 to 24
-- Updates the firedata file for the atack choppers, both AH1Z and MI28 have 45 rocketpods and 90 gunner cannon bullits

# Previous update: 30-04-2022
- ** Added BM-23 and M142
- 6 shells ? ,meh 24 !!!

# Previous update: 25-04-2022
- # Shotguns:
- Shotguns has massive increased ammo.

# Previous update: 05-04-2022
- **Added Sprut-SD and M1128 Stryker**
- Gravity ? ,what was that ??

# Previous update: 05-04-2022
- **Atack choppers has x3 more ammo**

# Previous update: 04-04-2022
- # Slightly changed the chopper, act more smoother
- Tweaks: Turned down Crossbow HE damage stuff..

# Previous update: 01-04-2022
- # Handguns weapons
- ADDED: All default handguns has increased ammo size
- M93r has unlimited ammo, but lower damage but bigger ammo clip

- # Common weapons
- ADDED: All shared weapons has increased ammo size

- # Assault class
- ADDED: All Asault weapons has increased ammo size

- # Engineer class
- ADDED: All Engineer weapons has increased ammo size !

- # Support class
- ADDED: All Support weapons has increased ammo size !

- # Recon class
- ADDED: All Sniper weapons has increased ammo size !



# Previous update: 30-03-2022
- CHANGED: 
- **Sorted all weapons in its class group**


# Previous update: 28-03-2022
- **TUGS** is now super charged with double sweep range ! 

# Previous update: 24-03-2022
- ADDED: Kinky Defib
- Now you also can cover the area with smoke !
- **Changed the module names**

# Previous update: 23-03-2022
- Changed: __init__ module loading procedure.
- Modules can now me turned on and off by setting true or false
- Or disabling them totaly.

- ADDED: EOD Bot has nut case repair range, and also shoots RPG
- EOD Bot is now gamemode depending

# Previous update: 20-03-2022
- CHANGED: TUGs now beeps faster

# Previous update: 15-03-2022
- In general: Enough changes made !

# Initial start: 10-03-2022
- Stripping down all unwanted stuff
- Give all modded items its own file structure

## Players
- You move now faster by 5% ,Running is like your are hunted by a bull.
- Stinger/Igla and Smaw/RPG are now available to both teams (MajorVictory87 unchanged)
- You are now a atletic swimmer !!

## Weapons
- **M93R** burst fire improved, lower damage but each clip has 16 bullits now
- UNLIMITED AMMO !!!!

## Crossbow
- Gravity WAS a biatch, hehe
- Damage is now smoll nuke area
- Bolts u can use is now gamemode depending

## Gadgets
- **Ammobag** heals and gives ammo, has a radius of 10 Meters - Moderate ammo refile speed - lower healing speed - You are now a medic in training !
- **Medicbag** heals and gives ammo, has a radius of 10 Meters - Moderate healing speed - lower ammo refil speed 
- Primary focus on getting a nice balance

## C4
- C4 u can use is now gamemode depending, 16 for conquest, 3 for TDM, 6 for rush and ctf

## M15 Mines
- M15 Mines u can use is now gamemode depending, 16 for conquest, 3 for TDM, 6 for rush and ctf

## Claymore
- Now explodes if enemy is in range, no longer directional, explosion buffed
- Increased MAG size to 8 and can place more !

## Grenades
- M67 Grenades u can use is now gamemode depending, 16 for conquest, 3 for TDM, 6 for rush and ctf

## SMAW
- SMAW is now gamemode depending, 40 for conquest, 6 for TDM, 10 for rush and ctf

## RPG-7
- RPG-7 is now gamemode depending, 40 for conquest, 6 for TDM, 10 for rush and ctf

## FGM148
- FGM148 Javelin is now gamemode depending, 40 for conquest, 60 for TDM, 10 for rush and ctf

## FIM92a
- FIM92a Stinger is now gamemode depending, 40 for conquest, 60 for TDM, 10 for rush and ctf

## Sa18IGLA
- Sa18IGLA Igla is now gamemode depending, 40 for conquest, 60 for TDM, 10 for rush and ctf

## Repair Tool
- No longer overheats, butane levels increased, range extended (\~20 meters but 1 meter in TDM mode and 3 meter in RUSH and CTF)
- Range u can use is now gamemode depending

## M224 Mortar
- Went to a few yoga classes and is now way more flexible (remember you can drop smokes by pressing 2 to switch projectiles)

## Vehicles
- **M1A2 Abrams** no damage mod, but no shell drop due no gravity ,time to live decreased to 4 seconds
- **T90** no damage mod, but no shell drop due no gravity ,time to live decreased to 4 seconds
- **Tunguska** cannon is more accurate, fire time doubled, finaly a nemesis against tanks !
- **LAV25** cannon is more accurate, fire time doubled, finaly a nemesis against tanks !
