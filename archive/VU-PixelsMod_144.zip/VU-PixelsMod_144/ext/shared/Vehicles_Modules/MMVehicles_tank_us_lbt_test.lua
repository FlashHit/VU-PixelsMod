class "MMVehicles_tank_us_lbt_test"

function MMVehicles_tank_us_lbt_test:Write(mmResources)
-- AMTRAC AAV-7A1

	if (mmResources:IsLoaded('lbt_shell3')) then
		mmResources:SetLoaded('lbt_shell3', false)

		local bulletData = FiringFunctionData(mmResources:GetInstance('lbt_shell3'))
		bulletData:MakeWritable()
		bulletData.ammo.magazineCapacity = 24

		print('Changed EXPERIMENTAL LBT Amtrac AAV-7A1 Shell Modifier ... ... ... ... ... ...')
	end

	if (mmResources:IsLoaded('lbt_shell3grav')) then
		mmResources:SetLoaded('lbt_shell3grav', false)

		local bulletData = BulletEntityData(mmResources:GetInstance('lbt_shell3grav'))
		bulletData:MakeWritable()
		bulletData.gravity = -1.0
		bulletData.timeToLive = 8.0

		print('Changed EXPERIMENTAL LBT Amtrac AAV-7A1 Gravity Modifier ... ... ... ... ... ...')
	end


-- US Phoenix - RU Barsuk

	if (mmResources:IsLoaded('lbt_shell4')) then
		mmResources:SetLoaded('lbt_shell4', false)

		local bulletData = FiringFunctionData(mmResources:GetInstance('lbt_shell4'))
		bulletData:MakeWritable()
		bulletData.ammo.magazineCapacity = 24
		print('Changed EXPERIMENTAL LBT Phoenix - Barsuk Shell Modifier ... ... ... ... ... ...')
	end

-- --------------------------------------------------------------------------------------------------------

end
return MMVehicles_tank_us_lbt_test()
