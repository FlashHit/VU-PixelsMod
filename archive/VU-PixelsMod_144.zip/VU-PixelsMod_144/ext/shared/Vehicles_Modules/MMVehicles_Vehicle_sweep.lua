class "MMVehicles_Vehicle_sweep"
function MMVehicles_Vehicle_sweep:Write(instance)

	if (mmResources:IsLoaded('radarsweep_lav25')) then
		mmResources:SetLoaded('radarsweep_lav25', false)

		local radarSweep = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('radarsweep_lav25'))

		radarSweep.controllableSweepRadius = 60
		radarSweep.controllableSweepInterval = 1.5
		radarSweep.sweepForMines = true
		radarSweep.mineSweepRadius = 60
		radarSweep.mineSweepInterval = 1.5
		dprint('Changed LAV-25 Radarsweep Range...')
	end

	if (mmResources:IsLoaded('radarsweep_lav25_1')) then
		mmResources:SetLoaded('radarsweep_lav25_1', false)

		local radarSweep = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('radarsweep_lav25_1'))

		radarSweep.controllableSweepRadius = 60
		radarSweep.controllableSweepInterval = 1.5
		radarSweep.sweepForMines = true
		radarSweep.mineSweepRadius = 60
		radarSweep.mineSweepInterval = 1.5
		dprint('Changed LAV-25 (1) Radarsweep Range...')
	end

	if (mmResources:IsLoaded('radarsweep_lavAD')) then
		mmResources:SetLoaded('radarsweep_lavAD', false)

		local radarSweep = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('radarsweep_lavAD'))

		radarSweep.controllableSweepRadius = 60
		radarSweep.controllableSweepInterval = 1.5
		radarSweep.sweepForMines = true
		radarSweep.mineSweepRadius = 60
		radarSweep.mineSweepInterval = 1.5
		dprint('Changed LAV-AD Radarsweep Range...')
	end

end
return MMVehicles_Vehicle_sweep()
