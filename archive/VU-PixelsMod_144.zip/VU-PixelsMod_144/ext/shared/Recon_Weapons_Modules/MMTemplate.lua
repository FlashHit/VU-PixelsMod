class "MMTemplate"

function MMTemplate:Write(mmResources)









		dprint('Empty template file...') 
end

return MMTemplate()