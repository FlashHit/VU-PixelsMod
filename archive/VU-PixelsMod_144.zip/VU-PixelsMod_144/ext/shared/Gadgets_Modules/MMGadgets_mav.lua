class "MMGadgets_mav"
function MMGadgets_mav:Write(instance)

	-- slow down regen rate to allow enetering vehicle before ammo refills
	if (mmResources:IsLoaded('mav_pda')) then
		mmResources:SetLoaded('mav_pda', false)
		local fireData = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('mav_pda'))
		fireData.ammo.ammoBagPickupDelayMultiplier = 30
		dprint('Changed MAV PDA...')
	end

--	if (mmResources:IsLoaded('mav_chassis')) then
--		mmResources:SetLoaded('mav_chassis', false)
--
--		local chassisData = ChassisComponentData(mmResources:GetInstance('mav_chassis'))
--		chassisData:MakeWritable()
--		chassisData.transform.left.x = 4
--		chassisData.transform.up.y = 1
--		chassisData.transform.forward.z = 1
--		print('Changed MAV Chassis...')
--	end

	if (mmResources:IsLoaded('mav_weapon') and mmResources:IsLoaded('rpgprojectile') and mmResources:IsLoaded('crossboltsound')) then
		mmResources:SetLoaded('mav_weapon', false)

		local boltBP = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('rpgprojectile'))

		local fireData = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('mav_weapon'))
		fireData.sound = SoundPatchAsset(mmResources:GetInstance('crossboltsound'))
		fireData.shot.projectileData:MakeWritable()
		fireData.shot.projectileData = ProjectileEntityData(boltBP.data)
		fireData.shot.projectile:MakeWritable()
		fireData.shot.projectile = nil
		fireData.shot.initialSpeed.z = 1000
--		fireData.shot.gravity = 0
		fireData.shot.numberOfBulletsPerShell = 15
		fireData.fireLogic.rateOfFire = 900
		fireData.ammo.magazineCapacity = -1

		fireData.dispersion[1].minAngle = 1
		fireData.dispersion[1].maxAngle = 3
		fireData.dispersion[1].increasePerShot = 0
		print('Changed MAV Weapon...')
	end

	if (mmResources:IsLoaded('mav_camera')) then
		mmResources:SetLoaded('mav_camera', false)

		local rotationData = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('mav_camera'))
		rotationData.useAngularConstraint = false
		print('Changed MAV Camera...')
	end

	if (mmResources:IsLoaded('mav_camera2')) then
		mmResources:SetLoaded('mav_camera2', false)

		local cameraData = ebxEditUtils:GetWritableInstance(mmResources:GetInstance('mav_camera2'))
		cameraData.inputSuppression.suppressVehicleInput[1].suppressingValue = 0.9
		print('Changed MAV Camera 2...')
	end






















end
return MMGadgets_mav()
