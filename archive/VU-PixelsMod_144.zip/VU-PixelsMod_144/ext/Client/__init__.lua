-- global funcs and utils
require('__shared/MMUtils')

-- load resource list
mmResources = require('__shared/MMResources')
